#!/usr/bin/env bash
# Installs SeedFinder for the current user under ~/.local, without root.
set -euo pipefail

here="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
bin_dir="${XDG_BIN_HOME:-$HOME/.local/bin}"
data_dir="${XDG_DATA_HOME:-$HOME/.local/share}"

install -Dm755 "$here/seedfinder" "$bin_dir/seedfinder"
install -Dm644 "$here/seedfinder.png" "$data_dir/icons/hicolor/512x512/apps/seedfinder.png"
install -Dm644 "$here/seedfinder.desktop" "$data_dir/applications/seedfinder.desktop"

if command -v update-desktop-database >/dev/null 2>&1; then
  update-desktop-database "$data_dir/applications" || true
fi
if command -v gtk-update-icon-cache >/dev/null 2>&1; then
  gtk-update-icon-cache -q -t "$data_dir/icons/hicolor" || true
fi

echo "SeedFinder installed: $bin_dir/seedfinder"
case ":$PATH:" in
  *":$bin_dir:"*) ;;
  *) echo "Note: $bin_dir is not on your PATH." ;;
esac
